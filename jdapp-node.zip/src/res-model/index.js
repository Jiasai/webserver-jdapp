/**
 * @description 返回数据模型 入口文件
 * @author Masion
 */

const SuccessModel = require('./SuccessModel');

const ErrorModel = require('./ErrorModel');

//整合输出

module.exports = {SuccessModel,ErrorModel}

